package co.edu.unbosque.GiraldoSantiago_Prog2;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GiraldoSantiagoProg2Application {

	public static void main(String[] args) {
		SpringApplication.run(GiraldoSantiagoProg2Application.class, args);
	}

}
