package co.edu.unbosque.GiraldoSantiago_Prog2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GiraldoSantiagoProg2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
